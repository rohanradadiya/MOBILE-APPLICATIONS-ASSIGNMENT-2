plugins {
    alias(libs.plugins.android.application) apply false
}