package com.example.locationfinderassignment2;

import android.text.InputFilter;
import android.text.Spanned;

//is the class called DecimalDigitsFilter, which allows the limiting of the inputs to strictly numbers and periods
//is made specifically for the latitude/longitude inputs so that the user can only input either numbers or periods, and no other characters.
public class DecimalDigitsFilter implements InputFilter {

    //represents the method to filter the input by the user.
    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        //allows only numbers and periods, looks over all of the characters.
        for (int i = start; i < end; i++) {
            //does the checking to see if the character is not a digit or a period.
            if (!Character.isDigit(source.charAt(i)) && source.charAt(i) != '.') {
                return "";
            }
        }
        //returns a null value to accept the input in the case that all of the characters are valid.
        return null;
    }
}
