package com.example.locationfinderassignment2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

//represents the class to display the list of locations.
public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {
    //represents the list of locations to display.
    private final List<Location> locationList;
    //represents the database helper to manage the different database operations.
    private final DatabaseHelper databaseHelper;
    private final Context context;

    //functions as a constructor for initializing LocationAdapter.
    public LocationAdapter(Context context, List<Location> locationList, DatabaseHelper databaseHelper) {
        this.context = context;
        //functions to set the list of the locations.
        this.locationList = locationList;
        //functions to set the database helper.
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.location_item, parent, false);
        //returns LocationViewHolder.
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        //retrieves the location at the given position.
        Location location = locationList.get(position);
        holder.bind(location);
    }

    //functions to return the total number of items in the current data set.
    @Override
    public int getItemCount() {
        return locationList.size();
    }

    public class LocationViewHolder extends RecyclerView.ViewHolder {
        //represents the TextViews for address, latitude and longitude values.
        private final TextView textViewAddress;
        private final TextView textViewLatitude;
        private final TextView textViewLongitude;
        //represents the button to be able to modify a location.
        private final Button buttonModify;
        //represents the button to be able to delete a location.
        private final Button buttonDelete;

        public LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            //finds the views according to their IDs.
            textViewAddress = itemView.findViewById(R.id.textViewAddress);
            textViewLatitude = itemView.findViewById(R.id.textViewLatitude);
            textViewLongitude = itemView.findViewById(R.id.textViewLongitude);
            buttonModify = itemView.findViewById(R.id.buttonModify);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }

        public void bind(Location location) {
            //represents the text for the relating data, and shows it to the user.
            textViewAddress.setText(location.getAddress());
            textViewLatitude.setText("Latitude: " + location.getLatitude());
            textViewLongitude.setText("Longitude: " + location.getLongitude());

            //OnClickListener for the modify button.
            buttonModify.setOnClickListener(v -> {
                Intent intent = new Intent(context, ModifyLocationActivity.class);
                //gives all of the location data to the activity for the modify button to function as required.
                intent.putExtra("LOCATION_ID", location.getId());
                intent.putExtra("ADDRESS", location.getAddress());
                intent.putExtra("LATITUDE", location.getLatitude());
                intent.putExtra("LONGITUDE", location.getLongitude());
                //starts the activity with the help of the intent.
                context.startActivity(intent);
            });

            //OnClickListener for the delete button.
            buttonDelete.setOnClickListener(v -> {
                //helps to delete the location from the database.
                databaseHelper.deleteLocation(location.getId());
                //helps to remove the location from the list.
                locationList.remove(getAdapterPosition());
                notifyItemRemoved(getAdapterPosition());
            });
        }
    }
}
