package com.example.locationfinderassignment2;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

//represents the MainActivity class, which is the main point of the application.
//one of the most important classes for the functioning of the application.
public class MainActivity extends AppCompatActivity {
    //represents the DatabaseHelper for the database operations.
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //layout for this activity.
        setContentView(R.layout.activity_main);

        //initialization of the DatabaseHelper.
        databaseHelper = new DatabaseHelper(this);

        //populates the database with the given sample data only if the database is empty.
        if (databaseHelper.getAllLocations().isEmpty()) {
            databaseHelper.populateDatabase();
        }

        //OnClickListener for the "Add Location" button.
        findViewById(R.id.buttonAddLocation).setOnClickListener(v -> {
            //necessary intent to start the activity.
            Intent intent = new Intent(MainActivity.this, AddLocationActivity.class);
            startActivity(intent);
        });

        //OnClickListener for the "View Locations" button.
        findViewById(R.id.buttonViewLocations).setOnClickListener(v -> {
            //necessary intent to start the activity.
            Intent intent = new Intent(MainActivity.this, ViewLocationsActivity.class);
            startActivity(intent);
        });

        //OnClickListener for the "Query Location" button.
        findViewById(R.id.buttonQueryLocation).setOnClickListener(v -> {
            //necessary intent to start the activity.
            Intent intent = new Intent(MainActivity.this, QueryLocationActivity.class);
            startActivity(intent);
        });
    }
}
