package com.example.locationfinderassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

//activity which allows the viewing of the list of the saved existing locations.
public class ViewLocationsActivity extends AppCompatActivity {

    //functions to display the list of locations.
    private RecyclerView recyclerView;
    private LocationAdapter locationAdapter;
    //database helper which helps to manage the different data.
    private DatabaseHelper databaseHelper;
    //represents the button which adds a new location.
    private Button buttonAddLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //sets the layout for activity_view_locations.
        setContentView(R.layout.activity_view_locations);

        //functions to initialize DatabaseHelper.
        databaseHelper = new DatabaseHelper(this);
        //finds through their IDs.
        recyclerView = findViewById(R.id.recyclerView);
        //represents the button to go back.
        Button buttonBack = findViewById(R.id.buttonBack);
        //represents the button to add location.
        buttonAddLocation = findViewById(R.id.buttonAddLocation);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //loads the locations.
        loadLocations();

        //OnClickListener for back button.
        buttonBack.setOnClickListener(v -> {
            //necessary intent for functioning of the button.
            Intent intent = new Intent(ViewLocationsActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        //OnClickListener for add location button.
        buttonAddLocation.setOnClickListener(v -> {
            //necessary intent for functioning of the button.
            Intent intent = new Intent(ViewLocationsActivity.this, AddLocationActivity.class);
            startActivity(intent);
            //functions to finish the current activity.
            finish();
        });
    }

    //loads the locations from the database.
    private void loadLocations() {
        //retrieves all of the locations from the database.
        List<Location> locations = databaseHelper.getAllLocations();
        //initializes adapter with list of locations.
        locationAdapter = new LocationAdapter(this, locations, databaseHelper);
        recyclerView.setAdapter(locationAdapter);
    }

    @Override
    public void onBackPressed() {
        //functions to override the back button so that it goes back to the main screen/
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
