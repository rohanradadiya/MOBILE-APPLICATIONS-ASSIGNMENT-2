package com.example.locationfinderassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

//represents an activity which allows to modify a location which already exists.
public class ModifyLocationActivity extends AppCompatActivity {
    //database helper which helps to manage database operations.
    private DatabaseHelper databaseHelper;
    //fields for the user to input text.
    private EditText editTextAddress, editTextLatitude, editTextLongitude;
    //represents the ID of the location to be modified.
    private int locationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_location);

        //initialization of the DatabaseHelper.
        databaseHelper = new DatabaseHelper(this);
        //EditTexts and button views according to their IDs.
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitude);
        //functions as a saving button, for a saving functionality.
        Button buttonSave = findViewById(R.id.buttonSave);

        //assists in helping to restrict the number of decimal places for the latitude and longitude fields.
        editTextLatitude.setFilters(new InputFilter[]{new DecimalDigitsFilter()});
        editTextLongitude.setFilters(new InputFilter[]{new DecimalDigitsFilter()});

        //functions to retrieve location details from intent.
        locationId = getIntent().getIntExtra("LOCATION_ID", -1);
        String address = getIntent().getStringExtra("ADDRESS");
        String latitude = getIntent().getStringExtra("LATITUDE");
        String longitude = getIntent().getStringExtra("LONGITUDE");

        //helps to set the retrieved location details to the editText fields.
        if (address != null) editTextAddress.setText(address);
        if (latitude != null) editTextLatitude.setText(latitude);
        if (longitude != null) editTextLongitude.setText(longitude);

        //represents the OnClickListener for the "Save" button.
        buttonSave.setOnClickListener(v -> {
            //retrieves the updated location details.
            String newAddress = editTextAddress.getText().toString();
            String newLatitude = editTextLatitude.getText().toString();
            String newLongitude = editTextLongitude.getText().toString();

            //updates the location with the new details.
            databaseHelper.updateLocation(locationId, newAddress, newLatitude, newLongitude);
            //helps to start the ViewLocationsActivity and goes to the list of locations.
            Intent intent = new Intent(ModifyLocationActivity.this, ViewLocationsActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        //override functionality to make sure that the back button goes to the main screen
        //better functionality for the user.
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
