package com.example.locationfinderassignment2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

//represents the DatabaseHelper class in order to be able to manage the database creation and versions.
public class DatabaseHelper extends SQLiteOpenHelper {
    //represents the database name.
    private static final String DATABASE_NAME = "LocationFinder.db";
    //represents the database version.
    private static final int DATABASE_VERSION = 1;
    //represents the table name and the table columns, in the database.
    private static final String TABLE_LOCATIONS = "locations";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_ADDRESS = "address";
    private static final String COLUMN_LATITUDE = "latitude";
    private static final String COLUMN_LONGITUDE = "longitude";

    //functions as a constructor to initialize the DatabaseHelper.
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //override is called when the database is generated for the first time.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_LOCATIONS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ADDRESS + " TEXT, " +
                COLUMN_LATITUDE + " TEXT, " +
                COLUMN_LONGITUDE + " TEXT)";
        db.execSQL(createTable);
    }

    //called when the database needs to be upgraded.
    //very useful when changes have been made to the database.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //creates a new table if an existing one already exists.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCATIONS);
        onCreate(db);
    }

    //represents a method which adds a location to the database
    public void addLocation(String address, String latitude, String longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ADDRESS, address);
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        //inserts the generated location in the locations table.
        db.insert(TABLE_LOCATIONS, null, values);
        db.close();
    }

    //functions as a method which populates the database with the sample locations provided.
    public void populateDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            for (Location location : getSampleLocations()) {
                ContentValues values = new ContentValues();
                values.put(COLUMN_ADDRESS, location.getAddress());
                values.put(COLUMN_LATITUDE, location.getLatitude());
                values.put(COLUMN_LONGITUDE, location.getLongitude());
                //functions to add each of these sample locations into the locations table.
                db.insert(TABLE_LOCATIONS, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    //represents the method which is a list of the locations provided, implemented in the code.
    //each location has an address, and latitude/longitude values to 4 decimal places which is just accurate enough for a good user experience.
    private List<Location> getSampleLocations() {
        List<Location> locations = new ArrayList<>();
        //adds the locations provided to the list.
        locations.add(new Location(1, "25 McCaul Street, Toronto", "43.6534", "-79.3913"));
        locations.add(new Location(2, "3000 Dufferin Street, Toronto", "43.7308", "-79.4486"));
        locations.add(new Location(3, "1300 Queen Street West, Toronto", "43.6517", "-79.4406"));
        locations.add(new Location(4, "2200 Eglinton Avenue East, Toronto", "43.7450", "-79.2967"));
        locations.add(new Location(5, "1860 Wilson Avenue, North York", "43.7357", "-79.4987"));
        locations.add(new Location(6, "95 Laird Drive, Toronto", "43.7102", "-79.3622"));
        locations.add(new Location(7, "600 Yonge Street, Toronto", "43.6728", "-79.3805"));
        locations.add(new Location(8, "40 King Street West, Toronto", "43.6473", "-79.3816"));
        locations.add(new Location(9, "600 Bay Street, Toronto", "43.6526", "-79.3831"));
        locations.add(new Location(10, "2301 Finch Avenue West, Toronto", "43.7650", "-79.5116"));
        locations.add(new Location(11, "1100 Eglinton Avenue East, Toronto", "43.7044", "-79.3588"));
        locations.add(new Location(12, "1300 Bayview Avenue, Toronto", "43.7084", "-79.3699"));
        locations.add(new Location(13, "200 Bloor Street West, Toronto", "43.6711", "-79.3846"));
        locations.add(new Location(14, "2320 Dundas Street West, Toronto", "43.6656", "-79.4868"));
        locations.add(new Location(15, "1234 Islington Avenue, Etobicoke", "43.6511", "-79.5320"));
        locations.add(new Location(16, "1000 Ellesmere Road, Scarborough", "43.7704", "-79.2339"));
        locations.add(new Location(17, "250 Front Street West, Toronto", "43.6465", "-79.3852"));
        locations.add(new Location(18, "1795 Lawrence Avenue East, Scarborough", "43.7554", "-79.2632"));
        locations.add(new Location(19, "41 Jarvis Street, Toronto", "43.6508", "-79.3708"));
        locations.add(new Location(20, "134 King Street East, Toronto", "43.6502", "-79.3712"));
        locations.add(new Location(21, "1100 King Street West, Toronto", "43.6453", "-79.4424"));
        locations.add(new Location(22, "1650 Dupont Street, Toronto", "43.6749", "-79.4678"));
        locations.add(new Location(23, "433 Bay Street, Toronto", "43.6517", "-79.3802"));
        locations.add(new Location(24, "1890 Queen Street East, Toronto", "43.6711", "-79.2860"));
        locations.add(new Location(25, "24 Duncan Street, Toronto", "43.6409", "-79.4091"));
        locations.add(new Location(26, "5200 Finch Avenue West, Toronto", "43.7608", "-79.5240"));
        locations.add(new Location(27, "56 St. Clair Avenue West, Toronto", "43.7044", "-79.3876"));
        locations.add(new Location(28, "415 Front Street West, Toronto", "43.6428", "-79.3917"));
        locations.add(new Location(29, "1663 Bayview Avenue, Toronto", "43.6946", "-79.3639"));
        locations.add(new Location(30, "123 Danforth Avenue, Toronto", "43.6761", "-79.3532"));
        locations.add(new Location(31, "22 York Street, Toronto", "43.6424", "-79.3781"));
        locations.add(new Location(32, "680 Sheppard Avenue West, North York", "43.7554", "-79.4127"));
        locations.add(new Location(33, "200 Front Street West, Toronto", "43.6435", "-79.3805"));
        locations.add(new Location(34, "625 Mount Pleasant Road, Toronto", "43.7096", "-79.3824"));
        locations.add(new Location(35, "1000 The Queensway, Toronto", "43.6352", "-79.5157"));
        locations.add(new Location(36, "81 Church Street, Toronto", "43.6471", "-79.3769"));
        locations.add(new Location(37, "1550 Steeles Avenue West, North York", "43.7773", "-79.5070"));
        locations.add(new Location(38, "11 Bathurst Street, Toronto", "43.6391", "-79.4090"));
        locations.add(new Location(39, "620 Richmond Street West, Toronto", "43.6465", "-79.4055"));
        locations.add(new Location(40, "1900 Yonge Street, Toronto", "43.7124", "-79.3968"));
        locations.add(new Location(41, "3030 Bloor Street West, Toronto", "43.6525", "-79.4979"));
        locations.add(new Location(42, "36 Eglinton Avenue West, Toronto", "43.7081", "-79.3956"));
        locations.add(new Location(43, "180 Queen Street West, Toronto", "43.6542", "-79.3856"));
        locations.add(new Location(44, "1990 Avenue Road, Toronto", "43.7423", "-79.4072"));
        locations.add(new Location(45, "1080 King Street West, Toronto", "43.6457", "-79.4522"));
        locations.add(new Location(46, "5 Wellesley Street East, Toronto", "43.6582", "-79.3800"));
        locations.add(new Location(47, "320 Queen Street West, Toronto", "43.6523", "-79.3977"));
        locations.add(new Location(48, "2075 Sheppard Avenue East, Toronto", "43.7707", "-79.3066"));
        locations.add(new Location(49, "3400 Dufferin Street, North York", "43.7250", "-79.4525"));
        locations.add(new Location(50, "1350 York Mills Road, North York", "43.7600", "-79.3354"));
        locations.add(new Location(51, "2388 Bloor Street West, Toronto", "43.6552", "-79.5108"));
        locations.add(new Location(52, "1515 Kingston Road, Scarborough", "43.7224", "-79.2741"));
        locations.add(new Location(53, "35 Kings Street East, Toronto", "43.6509", "-79.3808"));
        locations.add(new Location(54, "68 Spadina Avenue, Toronto", "43.6459", "-79.3979"));
        locations.add(new Location(55, "1750 Simcoe Street North, Oshawa", "43.9631", "-78.8661"));
        locations.add(new Location(56, "6200 Yonge Street, North York", "43.7512", "-79.4156"));
        locations.add(new Location(57, "5100 Dufferin Street, Toronto", "43.7328", "-79.4752"));
        locations.add(new Location(58, "80 Front Street East, Toronto", "43.6508", "-79.3663"));
        locations.add(new Location(59, "299 Queen Street West, Toronto", "43.6500", "-79.3894"));
        locations.add(new Location(60, "90 Eglinton Avenue West, Toronto", "43.7133", "-79.3891"));
        locations.add(new Location(61, "2500 Victoria Park Avenue, Toronto", "43.7610", "-79.2835"));
        locations.add(new Location(62, "1132 King Street West, Toronto", "43.6452", "-79.4406"));
        locations.add(new Location(63, "2040 Lawrence Avenue East, Scarborough", "43.7584", "-79.2580"));
        locations.add(new Location(64, "1010 Bay Street, Toronto", "43.6692", "-79.3849"));
        locations.add(new Location(65, "1150 Markham Road, Scarborough", "43.7484", "-79.2051"));
        locations.add(new Location(66, "1400 Jane Street, Toronto", "43.7184", "-79.5237"));
        locations.add(new Location(67, "2022 Gerrard Street East, Toronto", "43.6773", "-79.2931"));
        locations.add(new Location(68, "4000 Steeles Avenue West, Toronto", "43.7830", "-79.5226"));
        locations.add(new Location(69, "6000 Bathurst Street, North York", "43.7712", "-79.4571"));
        locations.add(new Location(70, "415 Eglinton Avenue East, Toronto", "43.7055", "-79.3754"));
        locations.add(new Location(71, "1900 Bayview Avenue, Toronto", "43.7179", "-79.3563"));
        locations.add(new Location(72, "2000 Markham Road, Scarborough", "43.7501", "-79.2068"));
        locations.add(new Location(73, "940 Finch Avenue West, Toronto", "43.7630", "-79.4997"));
        locations.add(new Location(74, "900 Dundas Street West, Toronto", "43.6549", "-79.4051"));
        locations.add(new Location(75, "775 Pacific Road, Oakville", "43.4634", "-79.6559"));
        locations.add(new Location(76, "2389 Kipling Avenue, Toronto", "43.7417", "-79.5473"));
        locations.add(new Location(77, "2150 Ellesmere Road, Scarborough", "43.7709", "-79.1967"));
        locations.add(new Location(78, "3200 Dundas Street West, Toronto", "43.6465", "-79.5252"));
        locations.add(new Location(79, "1790 Albion Road, Toronto", "43.7171", "-79.5663"));
        locations.add(new Location(80, "1225 Bloor Street West, Toronto", "43.6620", "-79.4407"));
        locations.add(new Location(81, "2100 Lawrence Avenue East, Scarborough", "43.7621", "-79.2432"));
        locations.add(new Location(82, "5 Gerrard Street East, Toronto", "43.6537", "-79.3805"));
        locations.add(new Location(83, "3500 Bathurst Street, Toronto", "43.7365", "-79.4482"));
        locations.add(new Location(84, "2200 Finch Avenue East, Toronto", "43.7732", "-79.3197"));
        locations.add(new Location(85, "1715 Bayview Avenue, Toronto", "43.7097", "-79.3594"));
        locations.add(new Location(86, "33 Yonge Street, Toronto", "43.6485", "-79.3788"));
        locations.add(new Location(87, "451 Warden Avenue, Scarborough", "43.7338", "-79.2606"));
        locations.add(new Location(88, "2500 Lawrence Avenue West, Toronto", "43.7037", "-79.5261"));
        locations.add(new Location(89, "450 Queen Street West, Toronto", "43.6496", "-79.4041"));
        locations.add(new Location(90, "800 College Street, Toronto", "43.6580", "-79.4216"));
        locations.add(new Location(91, "4600 Yonge Street, North York", "43.7510", "-79.4105"));
        locations.add(new Location(92, "1430 Queen Street West, Toronto", "43.6558", "-79.4422"));
        locations.add(new Location(93, "77 St. Clair Avenue West, Toronto", "43.7075", "-79.3885"));
        locations.add(new Location(94, "1890 Lakeshore Boulevard West, Toronto", "43.6277", "-79.4762"));
        locations.add(new Location(95, "1122 Gerrard Street East, Toronto", "43.6704", "-79.3165"));
        locations.add(new Location(96, "35 Finch Avenue East, Toronto", "43.7751", "-79.3635"));
        locations.add(new Location(97, "100 Queen Street West, Toronto", "43.6512", "-79.3828"));
        locations.add(new Location(98, "3700 Dufferin Street, Toronto", "43.7382", "-79.4695"));
        locations.add(new Location(99, "3150 Bayview Avenue, Toronto", "43.7499", "-79.3889"));
        locations.add(new Location(100, "2788 Kingston Road, Scarborough", "43.7360", "-79.2152"));
        //returns the locations provided.
        return locations;
    }

    //method which helps to delete a location from the database.
    public void deleteLocation(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //deletes the location from the locations table with the matching ID, to make sure that the correct location is deleted from the system.
        db.delete(TABLE_LOCATIONS, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    //represents a method which assists to get all locations from the database.
    public List<Location> getAllLocations() {
        List<Location> locationList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        //functions to query the location table in order to grab all of the locations.
        Cursor cursor = db.query(TABLE_LOCATIONS, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                //gets the location details.
                //holds multiple rows of data which helps to look through the data set.
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
                String address = cursor.getString(cursor.getColumnIndex(COLUMN_ADDRESS));
                String latitude = cursor.getString(cursor.getColumnIndex(COLUMN_LATITUDE));
                String longitude = cursor.getString(cursor.getColumnIndex(COLUMN_LONGITUDE));
                //adds the location to the list.
                locationList.add(new Location(id, address, latitude, longitude));
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return locationList;
    }

    //method which updates a location in the database.
    public void updateLocation(int id, String address, String latitude, String longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ADDRESS, address);
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        //functions to update the location in the locations table with the matching ID.
        db.update(TABLE_LOCATIONS, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    //method functions to get a location by an address.
    public Location getLocationByAddress(String address) {
        SQLiteDatabase db = this.getReadableDatabase();
        //functions to query the location from the locations table with the inputted address.
        //the address must match the one initially inputted, as the characters and spaces matter for the match.
        Cursor cursor = db.query(TABLE_LOCATIONS, null, COLUMN_ADDRESS + "=?", new String[]{address}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            //gets the location details, allows the accessing of data in each row and column.
            int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
            String latitude = cursor.getString(cursor.getColumnIndex(COLUMN_LATITUDE));
            String longitude = cursor.getString(cursor.getColumnIndex(COLUMN_LONGITUDE));
            cursor.close();
            //returns the location.
            return new Location(id, address, latitude, longitude);
        }
        //functions to return null if no location is found.
        //user is able to see that no location is found on the screen.
        return null;
    }
}
