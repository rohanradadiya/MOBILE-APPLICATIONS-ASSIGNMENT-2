package com.example.locationfinderassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

//represents a class and activity to function to display the list of the locations.
public class LocationListActivity extends AppCompatActivity {

    //helps to display the locations.
    private RecyclerView recyclerView;
    private LocationAdapter locationAdapter;
    //represents the database helper for the functioning of database operations.
    private DatabaseHelper databaseHelper;
    //button to add a new location.
    private Button buttonAddLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //sets the layout for this activity.
        setContentView(R.layout.activity_view_locations);

        //initializes the database helper.
        databaseHelper = new DatabaseHelper(this);
        //allows the searching of views according to their IDs.
        recyclerView = findViewById(R.id.recyclerView);
        buttonAddLocation = findViewById(R.id.buttonAddLocation);

        //sets the layout manager.
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //loads the locations and sets the adapter.
        loadLocations();

        //functions as an OnCLickListener for adding a location to the database.
        buttonAddLocation.setOnClickListener(v -> {
            //functions as an intent for starting AddLocationActivity.
            Intent intent = new Intent(LocationListActivity.this, AddLocationActivity.class);
            startActivity(intent);
        });
    }

    //functions as a method to load all of the locations from the database.
    private void loadLocations() {
        //retrieves all of the locations from the database.
        List<Location> locations = databaseHelper.getAllLocations();
        locationAdapter = new LocationAdapter(this, locations, databaseHelper);
        recyclerView.setAdapter(locationAdapter);
    }
}
