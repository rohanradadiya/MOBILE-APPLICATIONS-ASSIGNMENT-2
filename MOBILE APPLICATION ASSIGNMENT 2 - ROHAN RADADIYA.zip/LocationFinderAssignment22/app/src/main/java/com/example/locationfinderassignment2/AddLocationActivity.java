package com.example.locationfinderassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddLocationActivity extends AppCompatActivity {
    //database helper in order to manage the data in the program.
    private DatabaseHelper databaseHelper;
    //different fields in order to edit the text
    private EditText editTextAddress, editTextLatitude, editTextLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //allows the layout generation for this activity.
        setContentView(R.layout.activity_add_location);

        //represents the initialization of the DatabaseHelper in order to access the database.
        databaseHelper = new DatabaseHelper(this);
        //EditText elements with their button views, organized by IDs.
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitude);
        //represents the button which allows the saving of locations.
        Button buttonSave = findViewById(R.id.buttonSave);
        //represents the button which allows user to go back to the main screen.
        Button buttonBack = findViewById(R.id.buttonBack);

        //InputFilter which helps to limit the number of decimal places for the latitude and longitude values.
        editTextLatitude.setFilters(new InputFilter[]{new DecimalDigitsFilter()});
        editTextLongitude.setFilters(new InputFilter[]{new DecimalDigitsFilter()});

        //sets the OnClickListener which functions for the Save button and saves the location data when the user desires it.
        buttonSave.setOnClickListener(v -> {
            //receives the input from the EditText fields which removes any white spaces.
            //this makes the program more user-friendly and a better functionality of the program overall.
            String address = editTextAddress.getText().toString().trim();
            String latitude = editTextLatitude.getText().toString().trim();
            String longitude = editTextLongitude.getText().toString().trim();

            //checks for situations where any field is empty. (all fields must be filled in order to save a location)
            if (address.isEmpty() || latitude.isEmpty() || longitude.isEmpty()) {
                Toast toast = Toast.makeText(
                        //related message to the user which tells them to fill all of the fields in order to continue.
                        this, "All fields must be filled", Toast.LENGTH_SHORT
                );
                toast.setGravity(android.view.Gravity.CENTER, 0, 0);
                toast.show();
            } else {
                //adds a new location to the database
                databaseHelper.addLocation(address, latitude, longitude);
                //intent which starts MainActivity to go back to the main screen and complete the current activity.
                Intent intent = new Intent(AddLocationActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        //sets the OnClickListener for the "Back" button to navigate back to the main screen.
        buttonBack.setOnClickListener(v -> {
            //intent which starts MainActivity to go back to the main screen and finish the current one.
            Intent intent = new Intent(AddLocationActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        //makes sure that when the back button is pressed, it goes back to the main screen (overrides, not necessary, but provides a better functionality)
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
