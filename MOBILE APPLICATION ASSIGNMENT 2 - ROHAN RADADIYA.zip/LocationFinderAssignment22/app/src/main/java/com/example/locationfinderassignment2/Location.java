package com.example.locationfinderassignment2;

//represents the location class which is the class to represent a location with an ID, latitude and longitude values.
public class Location {
    //id which represents the location.
    private int id;
    //represents the address of the location.
    private String address;
    //represents the latitude value of the location.
    private String latitude;
    //represents the longitude value of the location.
    private String longitude;

    //constructor which functions to initialize a new location.
    public Location(int id, String address, String latitude, String longitude) {
        //sets the ID of the location, address, latitude, and longitude.
        this.id = id;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    //getter methods for the ID, address, latitude and longitudes.
    //returns each of the values.
    public int getId() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }
}
