package com.example.locationfinderassignment2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

//represents an activity which queries and displays the location by a specified address.
public class QueryLocationActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    //user input field.
    private EditText editTextQueryAddress;
    //displays the latitude and longitude values.
    private TextView textViewLatitude, textViewLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query_location);

        //initialization of the DatabaseHelper.
        databaseHelper = new DatabaseHelper(this);
        //finds the views by their IDs.
        editTextQueryAddress = findViewById(R.id.editTextQueryAddress);
        textViewLatitude = findViewById(R.id.textViewLatitude);
        textViewLongitude = findViewById(R.id.textViewLongitude);
        //button allows the search of the query.
        Button buttonQuery = findViewById(R.id.buttonQuery);
        //button allows to go back to the main screen.
        Button buttonBack = findViewById(R.id.buttonBack);

        //represents the OnClickListener for the query button.
        buttonQuery.setOnClickListener(v -> {
            //gets the address from the field.
            String address = editTextQueryAddress.getText().toString();
            //functions to query the location and search through the database.
            Location location = databaseHelper.getLocationByAddress(address);
            if (location != null) {
                //displays the necessary information of the location exists.
                textViewLatitude.setText("Latitude: " + location.getLatitude());
                textViewLongitude.setText("Longitude: " + location.getLongitude());
            } else {
                //displays a "Not found" message if the location does not exist.
                textViewLatitude.setText("Not found");
                textViewLongitude.setText("Not found");
            }
        });

        //represents the OnClickListener for the back button.
        buttonBack.setOnClickListener(v -> {
            finish();
        });
    }
}
